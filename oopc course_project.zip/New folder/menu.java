import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
 class menu1 extends JFrame implements ActionListener {
    // menubar
    static JMenuBar mb;
 
    // JMenu
    static JMenu x,y,z, x1,x2,x3,x4,y1,y2,y3,z1,z2,z3;
 
    // Menu items
    static JMenuItem m1, m2, m3, s1, s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13,s14,s15,s16,s17,s18,s19,s20,s21,s22,s23,s24,s25,s26,s27;
 
    // create a frame
    static JFrame f;
 
    // a label
    static JLabel l1,l2,l3,l;
 
    // main class
    public static void main(String[] args)
    {
        // create an object of the class
        menu1 m = new menu1();
 
        // create a frame
        f = new JFrame("***VEHICLE REGISTRATION***");
 
        // create a label
        l1 = new JLabel("no task ");
        l1.setBounds(1000,50, 200,100); 
	  l2 = new JLabel("no Vehcile is selected yet ");
        l2.setBounds(1000,60, 205,100); 
	  l3 = new JLabel("cost isn't displayed yet! ");
         
       
 
        // create a menubar
        mb = new JMenuBar();
 
        // create a menu
        x = new JMenu("City");
        y = new JMenu("Vehicle");
        z = new JMenu("cost");
        x1 = new JMenu("Hyderabad");
        x2 = new JMenu("Warangal");
        x3 = new JMenu("Karimnagar");
        x4 = new JMenu("Nizamabad");
	   y1 = new JMenu("2 Wheeler");
        y2 = new JMenu("Travelling ");
        y3 = new JMenu("loading vehs");
        z1 = new JMenu("2 Wheeler");
        z2 = new JMenu("Travelling ");
        z3 = new JMenu("loading vehs");
        
 
        // create menuitems
        s1 = new JMenuItem("Rreddy");
        s2 = new JMenuItem("Kutakpally");
        s3 = new JMenuItem("Nizampet");
        s4 = new JMenuItem("Hasanparty RTA");
        s5= new JMenuItem("Bhupalpally RTA");
        s6 = new JMenuItem("Gdk");
        s7 = new JMenuItem("Pedapalli");
        s8 = new JMenuItem("n RTA");
        s9= new JMenuItem("n2 RTA");
	   s10 = new JMenuItem("Bike");
        s11 = new JMenuItem("Scooty");
        s12= new JMenuItem("Auto");
        s13= new JMenuItem("Car");
        s14= new JMenuItem("Jeep");
        s15= new JMenuItem("Van");
        s16 = new JMenuItem("Lorry");
        s17 = new JMenuItem("Agri vehs");
        s18= new JMenuItem("Bus");
	   s19 = new JMenuItem("BIKE--Pay 2500/-");
        s20 = new JMenuItem("SCOOTY--Pay 2100/-");
        s21= new JMenuItem("AUTO--Pay 2600/-");
        s22= new JMenuItem("CAR--Pay 3000/-");
        s23= new JMenuItem("JEEP--Pay 3200/-");
        s24= new JMenuItem("VAN--Pay 3150/-");
        s25 = new JMenuItem("LORRY--Pay 6200/-");
        s26 = new JMenuItem("AGRI VEHS--Pay 5600/-");
        s27= new JMenuItem("BUS--Pay 3600/-");
        // add ActionListener to menuItems
        s1.addActionListener(m);
        s2.addActionListener(m);
        s3.addActionListener(m);
        s4.addActionListener(m);
        s5.addActionListener(m);
        s6.addActionListener(m);
        s7.addActionListener(m);
        s8.addActionListener(m);
        s9.addActionListener(m);
	   s10.addActionListener(m);
        s11.addActionListener(m);
        s12.addActionListener(m);
        s13.addActionListener(m);
        s14.addActionListener(m);
        s15.addActionListener(m);
        s16.addActionListener(m);
        s17.addActionListener(m);
        s18.addActionListener(m);
        s19.addActionListener(m);
	   s20.addActionListener(m);
        s21.addActionListener(m);
        s22.addActionListener(m);
        s23.addActionListener(m);
        s24.addActionListener(m);
        s25.addActionListener(m);
        s26.addActionListener(m);
        s27.addActionListener(m);

 
        // add menu items to menu
        x1.add(s1);
        x1.add(s2);
	   x1.add(s3);
        x2.add(s4);
        x2.add(s5);
        x3.add(s6);
        x3.add(s7);
        x4.add(s8);
        x4.add(s9);
        y1.add(s10);
        y1.add(s11);
        y2.add(s12);
	   y2.add(s13);
        y2.add(s14);
        y2.add(s15);
        y3.add(s16);
        y3.add(s17);
        y3.add(s18);
        z1.add(s19);
        z1.add(s20);
        z2.add(s21);
	   z2.add(s22);
        z2.add(s23);
        z2.add(s24);
        z3.add(s25);
        z3.add(s26);
        z3.add(s27);

	 


        // add submenu
        x.add(x1);
        x.add(x2);
	   x.add(x3);
        x.add(x4);
        y.add(y1);
	   y.add(y2);
        y.add(y3);
         z.add(z1);
	   z.add(z2);
        z.add(z3);
 
        // add menu to menu bar
        mb.add(x);
	   mb.add(y);
	   mb.add(z);
 
        // add menubar to frame
        f.setJMenuBar(mb);
 
        // add label
        f.add(l1);
       f.add(l2);
        f.add(l3);
 
        // set the size of the frame
        f.setSize(500, 500);
        f.setVisible(true);
       f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
    public void actionPerformed(ActionEvent e)
    {
        String s = e.getActionCommand();
        
        
        // set the label to the menuItem that is selected
       l1.setText(s + " selected");
        l2.setText(s + " selected");
        l3.setText("For " + s);   
    }
}